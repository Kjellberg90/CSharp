﻿using System;
// using Dugga.Uppgift1;
using Dugga.Uppgift2;
using Dugga.Uppgift3;
using Dugga.Uppgift4;
using Dugga.Uppgift5;
//using Dugga.Uppgift6;
//using Dugga.Uppgift7;

/*
  Om du vill testa din lösning på någon uppgift kan du använda
  denna fil för att skapa upp instanser och anropa metoder.

  Vi kommer inte utvärdera det som står i den här filen.

  Kom ihåg! Kör du fast på en uppgift kan det vara en bra idé
  att prova nästa uppgift i stället för att lägga mycket tid
  på en uppgift. Har du tid över i slutet kan du gå tillbaka
  till uppgiften du körde fast på.
 */

