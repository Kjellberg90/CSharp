﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dugga.Uppgift3
{
    class CreditCard
    {
        private string _benefitLevel;
        private int _creditLimit;

        public CreditCard(string benefitLevel)
        {
            _benefitLevel = benefitLevel;
            _creditLimit = 10000;
        }
    }
}
